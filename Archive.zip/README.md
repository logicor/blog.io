##introduction

JN's blog



