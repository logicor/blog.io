---
layout: post
title:  From the very beginning 
date: 2017-10-01
categories: blog
tags: [conclution]
description: The purpose of blogging
---

# From the very beginning

 As I get older, I think it's necessary to write something to record my life and study.
 I want to share what I see and what I learn online. I plan to weekly update.



